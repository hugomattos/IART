package GUI;

import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

import disease.Neural;

public class MainFrame extends JFrame{
	
	private static final long serialVersionUID = 3525929284228656819L;
	
	private JPanel contentPane;
	private double temperature;
	private int nausea, lumbar, urine, micturation, burning;
	JTextField boxTemperatura;
	boolean success = false;
	ButtonGroup param1,param2,param3,param4,param5;
	JRadioButton ButY1,ButY2,ButY3,ButY4,ButY5;
	JRadioButton ButN1,ButN2,ButN3,ButN4,ButN5;
	String result="";
	int learn, mom;
	int i = 0;
	JTextArea data,data2,data3;

	/**
	 * Launch the application.
	 */

	public static void main(String[] args) {
		new MainFrame();
	}


	/**
	 * Create the frame.
	 */
	public MainFrame() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		data = new JTextArea();
		data2 = new JTextArea();
		data3 = new JTextArea();
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new CardLayout(0, 0));
		getContentPane().setLayout(null);
		setContentPane(contentPane);

		final JPanel panel = new JPanel();


		panel.setBounds(10, 0, 157, 548);



		getContentPane().add(panel);
		panel.setLayout(null);

		JButton trainBut = new JButton("Train");
		trainBut.setBounds(220, 150, 133, 39);
		panel.add(trainBut);

		JButton guessBut = new JButton("Guess");
		guessBut.setBounds(220, 260, 133, 39);
		panel.add(guessBut);


		/*JButton optionBut = new JButton("Options");
		optionBut.setBounds(430, 460, 100, 30);
		panel.add(optionBut);
*/

		panel.setVisible(true);


		/*final JPanel stats = new JPanel();
		stats.setBounds(100, 300, 100, 100);
		final JTextArea Matrix = new JTextArea();
		stats.add(Matrix);
		stats.setVisible(false);
		add(stats);*/
		//Matrix.setBorder(BorderFactory.createLineBorder(Color.black));
/*
		optionBut.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) { 

				final JDialog jdia = new JDialog();
				jdia.setResizable(false);
				jdia.setModal(true);
				jdia.setBounds(800, 150, 300, 400);
				getContentPane().setLayout(null);

				final JPanel dia_panel = new JPanel();
				jdia.add(dia_panel);
				dia_panel.setBounds(600, 300, 100, 70);
				dia_panel.setLayout(null);


				final JLabel label = new JLabel("Learning Rate");
				label.setBounds(20, 20, 80, 20);
				dia_panel.add(label);

				//learning rate
				final JSlider learning;
				learning = new JSlider(0,10,3);
				learning.setToolTipText("Learning Rate");
				learning.setSnapToTicks(true);
				learning.setPaintTicks(true);
				learning.setPaintLabels(true);
				learning.setOrientation(SwingConstants.VERTICAL);
				learning.setMinorTickSpacing(1);
				learning.setMajorTickSpacing(10);

				learning.setBounds(41, 55, 57, 200);
				dia_panel.add(learning);

				//momentum
				final JLabel label2 = new JLabel("Momentum");
				label2.setBounds(200, 20, 80, 20);
				dia_panel.add(label2);


				final JSlider momentum;
				momentum = new JSlider(0,10,3);
				momentum.setToolTipText("Momentum");
				momentum.setSnapToTicks(true);
				momentum.setPaintTicks(true);
				momentum.setPaintLabels(true);
				momentum.setOrientation(SwingConstants.VERTICAL);
				momentum.setMinorTickSpacing(1);
				momentum.setMajorTickSpacing(10);

				momentum.setBounds(200, 55, 57, 200);
				dia_panel.add(momentum);


				JButton change = new JButton("change");
				change.setBounds(100, 280, 100, 30);
				dia_panel.add(change);

				
				change.addActionListener(new ActionListener() { 
					public void actionPerformed(ActionEvent e) { 
						learn = learning.getValue();
						mom = momentum.getValue();

						dia_panel.setVisible(false);
						jdia.setVisible(false);
						jdia.dispose();
						getContentPane().repaint();

					}
				});
				jdia.setVisible(true);
				jdia.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);


				

				//dia_panel.setVisible(false);
				//getContentPane().requestFocusInWindow();
				//dispose();

				//sliderNumDragoes.getValue();
				//getContentPane().repaint();

			}
		});*/


		trainBut.addActionListener(new ActionListener() { 
			public void actionPerformed(ActionEvent e) { 
				Neural.train();

				getContentPane().removeAll();

				final JPanel m = new JPanel();
				m.setBounds(10, 0, 157, 548);
				getContentPane().add(m);
				m.setLayout(null);


				final JTextArea Results = new JTextArea(Neural.train());
				Results.setBounds(130,40,320,250);
				Results.setBorder(BorderFactory.createLineBorder(Color.black));
				m.add(Results);

				final JTextArea Matrix = new JTextArea();
				Matrix.setBounds(215, 330, 170, 100);
				Matrix.setBorder(BorderFactory.createLineBorder(Color.black));
				m.add(Matrix);

				Matrix.insert(Neural.matrix,0);

				getContentPane().add(m);

				getContentPane().revalidate();
				getContentPane().repaint();
			} 
		} );

		guessBut.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				

				getContentPane().removeAll();

				final JPanel panel1 = new JPanel();
				panel1.setBounds(10, 0, 157, 548);
				getContentPane().add(panel1);
				panel1.setLayout(null);


				JLabel lblOpesDeJogo = new JLabel("Sintomas");
				lblOpesDeJogo.setBounds(20, 0, 133, 39);
				panel1.add(lblOpesDeJogo);
				lblOpesDeJogo.setFont(new Font("Dialog", Font.BOLD, 15));

				JLabel lblTamanhoDoLabirinto = new JLabel("Febre");
				lblTamanhoDoLabirinto.setBounds(35, 55, 78, 14);
				panel1.add(lblTamanhoDoLabirinto);

				boxTemperatura = new JTextField();
				boxTemperatura.setText(" ");
				boxTemperatura.setFont(new Font("Tahoma", Font.PLAIN, 14));
				boxTemperatura.setHorizontalAlignment(SwingConstants.CENTER);
				boxTemperatura.setColumns(10);
				boxTemperatura.setBounds(98, 50, 46, 30);
				panel1.add(boxTemperatura);

				JPanel panel_1 = new JPanel();
				panel_1.setBounds(20, 100, 170, 500);
				panel1.add(panel_1);
				panel_1.setLayout(null);

				//--------------------------------------
				JLabel lblSelecionarOQue = new JLabel("Occurence of Nausea");
				lblSelecionarOQue.setBounds(15, 11, 157, 14);
				panel_1.add(lblSelecionarOQue);


				param1 = new ButtonGroup();

				ButY1 = new JRadioButton("yes");
				ButY1.setSelected(true);
				ButY1.setBounds(15, 35, 83, 23);
				panel_1.add(ButY1);
				param1.add(ButY1);

				ButN1 = new JRadioButton("no");
				ButN1.setSelected(true);
				ButN1.setBounds(100, 35, 83, 23);
				panel_1.add(ButN1);
				param1.add(ButN1);


				//---------------------------------------------

				JLabel lblSelecionarLu = new JLabel("Lumbar Pain");
				lblSelecionarLu.setBounds(15, 80, 157, 14);
				panel_1.add(lblSelecionarLu);


				param2 = new ButtonGroup();

				ButY2 = new JRadioButton("yes");
				ButY2.setSelected(true);
				ButY2.setBounds(15, 104, 83, 23);
				panel_1.add(ButY2);
				param2.add(ButY2);

				ButN2 = new JRadioButton("no");
				ButN2.setSelected(true);
				ButN2.setBounds(100, 104, 83, 23);
				panel_1.add(ButN2);
				param2.add(ButN2);


				//----------------------------------------------

				JLabel lblSelecionarU = new JLabel("Urine Pushing");
				lblSelecionarU.setBounds(15, 149, 157, 14);
				panel_1.add(lblSelecionarU);


				ButtonGroup param3 = new ButtonGroup();

				ButY3 = new JRadioButton("yes");
				ButY3.setSelected(true);
				ButY3.setBounds(15, 173, 83, 23);
				panel_1.add(ButY3);
				param3.add(ButY3);

				ButN3 = new JRadioButton("no");
				ButN3.setSelected(true);
				ButN3.setBounds(100, 173, 83, 23);
				panel_1.add(ButN3);
				param3.add(ButN3);

				//----------------------------------------------

				JLabel lblSelecionarMic = new JLabel("Micturation Pains");
				lblSelecionarMic.setBounds(15, 222, 157, 14);
				panel_1.add(lblSelecionarMic);


				ButtonGroup param4 = new ButtonGroup();

				ButY4 = new JRadioButton("yes");
				ButY4.setSelected(true);
				ButY4.setBounds(15, 246, 83, 23);
				panel_1.add(ButY4);
				param4.add(ButY4);

				ButN4 = new JRadioButton("no");
				ButN4.setSelected(true);
				ButN4.setBounds(100, 246, 83, 23);
				panel_1.add(ButN4);
				param4.add(ButN4);


				//--------------------------------------------


				JLabel lblSelecionarBu = new JLabel("Burning of Urethra");
				lblSelecionarBu.setBounds(15, 295, 157, 14);
				panel_1.add(lblSelecionarBu);


				ButtonGroup param5 = new ButtonGroup();

				ButY5 = new JRadioButton("yes");
				ButY5.setSelected(true);
				ButY5.setBounds(15, 319, 83, 23);
				panel_1.add(ButY5);
				param5.add(ButY5);

				ButN5 = new JRadioButton("no");
				ButN5.setSelected(true);
				ButN5.setBounds(100, 319, 83, 23);
				panel_1.add(ButN5);
				param5.add(ButN5);


				//----------------------------


				JButton Submit = new JButton("Submit");
				Submit.setBounds(50, 370, 83, 23);
				panel_1.add(Submit);

				Submit.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {

						result = "";
						
						if(!(boxTemperatura.getText().trim()).equals("")){
							success = true;

							try{
								temperature = Double.parseDouble(boxTemperatura.getText().trim());
								result = result + temperature+"\n";

							}
							catch(NumberFormatException e)
							{
								System.out.println("Temperatura n�o v�lida");
								success = false;
							}



							if (success == true){
								//System.out.println(temperature);
								if(ButY1.isSelected()){
									//System.out.println("has nauseas");
									nausea = 0;
									result = result + "has nauseas\n";
								}
								else{
									//System.out.println("no nauseas");
									nausea = 1;
									result = result + "no nauseas\n";
								}

								if(ButY2.isSelected()){
									//System.out.println("has lumbar pain");
									lumbar = 0;
									result = result + "has lumbar pain\n";
								}
								else{
									//System.out.println("no lumbar pain");
									lumbar = 1;
									result = result + "no lumbar pain\n";
								}


								if(ButY3.isSelected()){
									//System.out.println("has urine pushing");
									urine = 0;
									result = result + "has urine pushing\n";
								}
								else{
									//System.out.println("no urine pushing");
									urine = 1;
									result = result + "no urine pushing\n";
								}

								if(ButY4.isSelected()){
									//System.out.println("has micturition pains");
									micturation = 0;
									result = result + "has micturition pains\n";
								}
								else{
									//System.out.println("no micturition pains");
									micturation = 1;
									result = result + "no micturition pains\n";
								}

								if(ButY5.isSelected()){
									//System.out.println("has burning of urethra");
									burning = 0;
									result = result + "has burning of urethra\n";
								}
								else{
									//System.out.println("no burning of urethra");
									burning = 1;
									result = result + "no burning of urethra\n";
								}
								ArrayList<String> moo;

								moo = Neural.guess(temperature,nausea,lumbar,urine,micturation,burning);


								//sintomas
								JLabel lab = new JLabel("Sintomas");
								lab.setBounds(270,15,250,50);
								panel1.add(lab);

								
								data.setBounds(270,55,250,120);
								panel1.add(data);

								
								data.setText(result);
								
								data.setBorder(BorderFactory.createLineBorder(Color.black));
								
								System.out.println(data.getText());
								
								
								// Box 1
								JLabel lab2 = new JLabel("Doen�a 1");
								lab2.setBounds(270,200,250,50);
								panel1.add(lab2);

								
								//data2 = new JTextArea();
								data2.setBounds(270,240,250,30);
								panel1.add(data2);

								data2.setText(moo.get(0));
								data2.setBorder(BorderFactory.createLineBorder(Color.black));


								// Box 2
								JLabel lab3 = new JLabel("Doen�a 2");
								lab3.setBounds(270,280,250,50);
								panel1.add(lab3);


								//data3 = new JTextArea();
								data3.setBounds(270,320,250,30);
								panel1.add(data3);
								data3.setBorder(BorderFactory.createLineBorder(Color.black));
								data3.setText(moo.get(1));
								
								
								getContentPane().revalidate();
								getContentPane().repaint();
								
							
							}


						}
					}

				})
				;

				getContentPane().revalidate();
				getContentPane().repaint();
			}


		});



		setSize(600,600);//Size of JFrame
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setVisible(true);//Sets if its visible.

	}

}
