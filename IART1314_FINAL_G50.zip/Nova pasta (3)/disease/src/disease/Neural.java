package disease;

import java.util.ArrayList;
import java.util.Random;

import weka.core.converters.ConverterUtils.DataSource;
import weka.classifiers.Classifier;
import weka.classifiers.Evaluation;
import weka.classifiers.functions.MultilayerPerceptron;
import weka.core.Attribute;
import weka.core.DenseInstance;
import weka.core.Instance;
import weka.core.Instances;


public class Neural {
	public static String matrix; 
	private static Instance inst_co;
	static Instances info;
	static DataSource file;

	public static String train(){
		

		try {
			file = new DataSource("disease.arff");
			
			info = file.getDataSet();
			info.setClassIndex(info.numAttributes() - 1);

			MultilayerPerceptron neural = new MultilayerPerceptron();         // set the options
			neural.buildClassifier(info);   // build classifier
			neural.setHiddenLayers("o");


			//weka.core.SerializationHelper.write("disease.model", cls);

			Evaluation eval = new Evaluation(info);
			System.out.println("Matrix:");
			eval.crossValidateModel(neural, info, 10, new Random(1));
			//eval.evaluateModel(neural, info);
			System.out.print(matrix = eval.toMatrixString());
			System.out.println(eval.toSummaryString("\nResults\n======\n", false));
			return eval.toSummaryString("\nResults\n======\n", false);

		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return "";
	}

	public static ArrayList<String> guess(double tempe, int nausea, int lumbar, int urine, int micturation, int burning){
//public static void guess(){
		double result = -1,result2 = -2;
		String result_s = null,result_s2 = null;
		ArrayList<String> res = new ArrayList<String>();
		try {
			file = new DataSource("disease.arff");
			info = file.getDataSet();
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		ArrayList<Attribute> attributeList = new ArrayList<Attribute>(8);
		
		Attribute temp = new Attribute("temperature");
		Attribute naus = new Attribute("nausea");
		Attribute lumb = new Attribute("lumbar_pain");
		Attribute urin = new Attribute("urine_pushing");
		Attribute mict = new Attribute("micturition_pain");
		Attribute burn = new Attribute("burning");
		
		
		
		ArrayList<String> classVal = new ArrayList<String>(2);
		classVal.add("ClassA");
		classVal.add("ClassB");
		
		attributeList.add(temp);
		attributeList.add(naus);
		attributeList.add(lumb);
		attributeList.add(urin);
		attributeList.add(mict);
		attributeList.add(burn);
		attributeList.add(new Attribute("@@class@@",classVal));

		Instances data = new Instances("TestInstances",attributeList,0);
		
		inst_co = new DenseInstance(8);
		data.add(inst_co);
		
		
		inst_co.setValue(temp,tempe);
		inst_co.setValue(naus,nausea);
		inst_co.setValue(lumb,lumbar);
		inst_co.setValue(urin,urine);
		inst_co.setValue(mict,micturation);
		inst_co.setValue(burn,burning);


		MultilayerPerceptron neural = new MultilayerPerceptron();         // set the options
		neural.setHiddenLayers("o");
		
		
		// 1� classe
		
		info.setClassIndex(info.numAttributes() - 2);

		try {

			
			neural.buildClassifier(info);   // build classifier	
			weka.core.SerializationHelper.write("at1.model", neural);
						
			Classifier cls_co = (Classifier) weka.core.SerializationHelper.read("at1.model");
			inst_co.setDataset(info);
			
			result = cls_co.classifyInstance(inst_co);
			
			if (result == 1){
				result_s = "No Nephritis of renal pelvis origin\n";
			}
			else
				result_s = "Nephritis of renal pelvis origin\n";
			//System.out.println(result_s);
			
			
			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

		// 2� classe
		
		info.setClassIndex(info.numAttributes() - 1);
		
		try {
			neural.buildClassifier(info);
			weka.core.SerializationHelper.write("at2.model", neural);
			
			Classifier cls_co = (Classifier) weka.core.SerializationHelper.read("at2.model");
			inst_co.setDataset(info);
			
			result2 = cls_co.classifyInstance(inst_co);
			
			if (result2 == 1){
				result_s2 = "No Inflamation of urinary bladder\n";
			}
			else
				result_s2 = "Inflamation of urinary bladder\n";
			//System.out.println(result_s2);
			
			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}   // build classifier	
		
		res.add(result_s);
		res.add(result_s2);
		
		
		return res;
	}

	public String getMatrix(){

		return matrix;
	}
}
