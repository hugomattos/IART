============ README ===================

Menu Principal: Possui 2 op��es: Train e Guess.

Train: Ao escolher esta op��o, o programa mostra ao utilizador todas as estatisticas
e "previs�es" do dataSet ja existente.(% de acerto, matriz de confus�o,etc..)

Guess: Ao escolher esta op��o, a interface mostra uma s�rie de op��es relativas aos 
sintomas da pessoa (febre, dores ao urinar, etc..). Ap�s escolher os sintomas que achar adequados
basta premir o bot�o Submit, e na parte direita da janela aparecer�o 3 caixas de texto:

1- Contem os sintomas inseridos, em modo de texto.
2- Progn�stico relativamente � doen�a 1
3- Progn�stico relativamente � doen�a 2